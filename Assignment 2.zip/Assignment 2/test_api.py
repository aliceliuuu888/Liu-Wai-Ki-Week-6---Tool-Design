# test_api.py
from tool import APIBasedExtractor
import json

def test_api():
    print("="*60)
    print("🔬 DeepSeek API 测试")
    print("="*60)
    
    # 创建 API 提取器
    extractor = APIBasedExtractor()
    
    # 测试文本
    text = """
   英伟达(NVIDIA)今日发布2025财年第一季度财报。营收达到260亿美元，同比增长262%，创历史新高。数据中心业务营收226亿美元，同比增长427%。游戏业务营收26亿美元，同比增长18%。公司宣布将进行1股拆10股的股票拆分计划，并提高季度股息150%。黄仁勋表示，Blackwell平台已全面投产，预计今年将为公司带来显著收入增长。分析师预计，英伟达下一季度营收将达到280亿美元。公司股价在盘后交易中上涨超过5%。
    """
    
    print(f"\n📝 输入文本长度: {len(text)} 字符")
    print("\n正在调用 DeepSeek API...")
    
    # 调用 API
    result = extractor.execute(text, max_points=5)
    
    if result["success"]:
        print("\n✅ API 调用成功！")
        print("\n📊 提取结果:")
        print(f"\n🔑 关键点:")
        for i, point in enumerate(result.get("key_points", []), 1):
            print(f"   {i}. {point}")
        
        print(f"\n📋 摘要:")
        print(f"   {result.get('summary', 'N/A')}")
        
        print(f"\n⚡ 行动项:")
        for item in result.get("action_items", []):
            print(f"   • {item}")
        
        print(f"\n👥 利益相关者影响:")
        for k, v in result.get("stakeholder_impact", {}).items():
            print(f"   • {k}: {v}")
    else:
        print(f"\n❌ API 调用失败: {result.get('error')}")
        if result.get("fallback"):
            print("\n使用本地规则作为备选:")
            fallback = result["fallback"]
            print(f"关键点: {fallback.get('key_points', [])}")

if __name__ == "__main__":
    test_api()